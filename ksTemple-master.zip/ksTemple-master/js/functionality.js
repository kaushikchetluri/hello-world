var i = 0;
function clickLike() {
  console.log("liked", i);
  document.getElementById("like").value = ++i;
  document.getElementById("like").innerHTML = "" + i;
}
